

import os.path
from envio import *


def validar_rango(inf, sup, msj):
    valor = int(input(msj))
    while sup < valor or valor < inf:
        print("El valor ingresado no es correcto. Intente nuevamente.")
        valor = int(input(msj))
    return valor


def validar_mayor(inf, msj):
    valor = int(input(msj))
    while valor <= inf:
        print("El valor ingresado no es correcto. Intente nuevamente.")
        valor = int(input(msj))
    return valor


def cargar_desde_archivo(v, tc, fd):
    if not os.path.exists(fd):
        print('El archivo', fd, 'no existe...')
        print('Revise..')
        return

    pr = True
    m = open(fd, "rt")
    for line in m:
        if pr is True:
            if "SC" in line:
                tc = "SC"
            pr = False

        else:
            cp = line[0:9].strip().upper()      # str
            direccion = line[9:29].strip()      # str
            tipo = int(line[29])                # int
            pago = int(line[30])                # int

            env = Envio(cp, direccion, tipo, pago)
            v.append(env)

    m.close()
    return tc


def opcion1(v, tc, fd):
    if len(v) != 0:
        r = int(input("¿Desea borrar los datos previos? (1: Si - 2: No (volver al menu): "))
        if r == 1:
            v = []
            tc = cargar_desde_archivo(v, tc, fd)
            print("Carga terminada...")
        else:
            print("Carga cancelada... El arreglo mantiene los datos que contenia...")
    else:
        tc = cargar_desde_archivo(v, tc, fd)
        print("Carga terminada...")

    print()
    return v, tc


def opcion2(v):
    m = validar_mayor(0, "Cuantos registros quiere agregar al arreglo (al menos 1)?: ")

    for i in range(m):
        cod = input("Codigo postal: ")
        dp = input("Direccion postal: ")
        tip = validar_rango(0, 6, "Tipo de envio (entre 0 y 6): ")
        fp = validar_rango(1, 2, "Forma de pago (entre 1 y 2): ")

        env = Envio(cod, dp, tip, fp)
        v.append(env)

    print("Carga terminada")
    print()


def ordenar(v):
    n = len(v)
    for i in range(n - 1):
        for j in range(i + 1, n):
            if v[i].codigo > v[j].codigo:
                v[i], v[j] = v[j], v[i]


def opcion3(v):
    n = len(v)
    ordenar(v)
    print("Hay", n, "registros en el arreglo")
    m = validar_rango(1, n, "Cantidad a mostrar (al menos 1 y no mas de " + str(n) + ")?: ")
    print("Listado de envios ordenados por codigo postal...")
    for i in range(m):
        print(v[i])

    print()


# ======================================================================
#                       Opcion 5
# ======================================================================



def busqueda_secuencial_op5(v, cp):     # cp = s
    pos = -1

    # indices    0          1           2
    # v = [     E1,         E2,         E3]
    # cp        x           s            t

    for i in range(len(v)):     # range(3)
        # i = 0, 1,         2

        # if v[i].tipo == t and v[i].sdsa == x:
        if v[i].codigo == cp:
            pos = i
            break       # romper el ciclo for

    return pos              # 0 o más    , -1  no encontramos resultado


def generar_vector_acum_op6(v, tc):

    v_conteo = [0] * 7

    for i in range(len(v)):

        indice = v[i].tipo

        if tc == "HC":
            if v[i].check_dir():        # si esta funcion devuelve True
                v_conteo[indice] += 1

        else:       # camino del "SC"

            v_conteo[indice] += 1

    # Mostrar el vector
    for i in range(len(v_conteo)):        # range(7)
        # i = 0, 1, ..., 6
        print("Para el tipo de envio:", i, "tiene un conteo de:", v_conteo[i])
# ======================================================================
#                       Opcion 7
# ======================================================================
def generar_vector_acum_op7(v, tc):

    # generar el vector de conteo / acum
    v_acum = [0] * 7

    # indices   0    1  2  3  4  5    6         -> los indices representan al atributo tipo de envio
    # v_acum = [6.5, 0, 0, 0, 0, 2.5, 0]

    # rellenar el vector de conteo / acum
    # indices       0          1           2
    # v = [         E1,         E2,         E3]
    # importe       1.5         2.5         5.0
    # tipo          0           5           0
    for i in range(len(v)):     # range(3)
        # i = 0,   1,  2

        indice = v[i].tipo

        if tc == "HC":
            if v[i].check_dir():        # si esta funcion devuelve True

                # asi se calcula el importe
                importe = v[i].calcular_importe()

                print("IMporte:", importe, "y del tipo", v[i].tipo)


                v_acum[indice] += importe

        else:       # camino del "SC"

            # asi se calcula el importe
            importe = v[i].calcular_importe()
            v_acum[indice] += importe

    # Mostrar el vector
    for i in range(len(v_acum)):        # range(7)
        # i = 0, 1, ..., 6
        print("Para el tipo de envio:", i, "tiene un acumulado de:", v_acum[i])

    return v_acum


def principal():
    # variable para almacenar en forma centralizada el nombre fisico del archivo de texto...
    fd = "envios-tp3.txt"
    # fd = "envios-prueba.txt"

    # variable para guardar en forma centralizada el tipo de control de direcciones vigente (por default, "HC")...
    tc = "HC"           # "HC" o "SC"

    # la referencia al arreglo...
    v = []

    v_acum_op7 = []

    op = 0
    while op != 10:
        print("Trabajo Practico 3")
        print("1. Cargar arreglo desde archivo de texto")
        print("2. Cargar arreglo desde teclado")
        print("3. Listado ordenado")
        print("4. Busqueda por direccion")
        print("5. Busqueda por codigo postal")
        print("6. Cantidad de envios con direccion válida")
        print("7. Importe final acumulado")
        print("8. Envio con mayor importe")
        print("9. Importe final promedio")
        print("10. Salir")
        op = int(input("Ingrese numero de opcion: "))

        if op == 1:
            # v = vector de trabajo
            # tc = tipo de control que es HC O SC
            v, tc = opcion1(v, tc, fd)

        elif op == 2:
            opcion2(v)

        elif op == 3:
            if len(v) != 0:
                opcion3(v)
            else:
                print("Todavia no hay datos cargados en el arreglo...")
                print()

        elif op == 4:
            pass

        elif op == 5:
            if len(v) > 0:
                # si una variable esta igualada a funcion es porque espero que la funcion devuelva algo

                cp = input("Ingresar codigo postal a buscar: ")
                pos = busqueda_secuencial_op5(v, cp)        # 1

                if pos >= 0:
                    print("Datos Viejos:", v[pos])

                    if v[pos].pago == 1:
                        v[pos].pago = 2
                    else:
                        v[pos].pago = 1

                    print("Datos Actualizados:", v[pos])

                else:       # seria el caso cuando toca -1
                    print("NO encontramos un Envio que tenga ese cp:", cp)

            else:
                print("Todavia no hay datos cargados en el arreglo...")
                print()


        elif op == 6:
            pass

        elif op == 7:
            if len(v) != 0:
                v_acum_op7 = generar_vector_acum_op7(v, tc)
            else:
                print("Todavia no hay datos cargados en el arreglo...")
                print()


        elif op == 8:

            if len(v_acum_op7) > 0:

                for i in range(len(v_acum_op7)):
                    pass

                pass
                # opcion8(v_acum_op7)
            else:
                print("No se ingreso a la opcion 7")

        elif op == 9:

            for i in range(len(v)):
                importe = v[i].calcular_importe()



if __name__ == "__main__":
    principal()
